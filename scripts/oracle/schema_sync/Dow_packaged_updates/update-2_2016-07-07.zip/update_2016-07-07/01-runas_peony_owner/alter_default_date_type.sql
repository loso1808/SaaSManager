alter table "custom_field" modify ("defaultValueDate" DATE);
alter table "z_custom_field" modify ("defaultValueDate" DATE);

alter table "custom_field_value" modify ("valueDate" DATE);
alter table "z_custom_field_value" modify ("valueDate" DATE);