alter table "custom_field" add ("isAdminCreated" NUMBER);
alter table "z_custom_field" add ("isAdminCreated" NUMBER);