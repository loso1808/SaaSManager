--------------------------------------------------------
--  DDL for Index part_sequence_idx
--------------------------------------------------------

  CREATE INDEX "part_sequence_idx" ON "part" ("sequence_id");
