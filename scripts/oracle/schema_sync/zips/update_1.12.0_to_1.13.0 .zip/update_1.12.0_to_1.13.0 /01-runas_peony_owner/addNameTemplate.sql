
alter table "next_level_part" add ("nameTemplate" varchar2(4000));

alter table "z_next_level_part" add ("nameTemplate" varchar2(4000));