
alter table "z_custom_field_value" modify ("logSessionId" VARCHAR2(50));