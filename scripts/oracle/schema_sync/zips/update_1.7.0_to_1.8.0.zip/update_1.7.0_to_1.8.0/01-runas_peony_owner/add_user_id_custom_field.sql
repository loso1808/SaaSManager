alter table "custom_field" add ("user_id" NUMBER);
alter table "z_custom_field" add ("user_id" NUMBER);

alter table "custom_field_value" add ("user_id" NUMBER);
alter table "z_custom_field_value" add ("user_id" NUMBER);