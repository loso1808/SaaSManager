

ALTER TABLE "j5run" ADD ("isShared" NUMBER);
ALTER TABLE "z_j5run" ADD ("isShared" NUMBER);

ALTER TABLE "devicedesign" ADD ("description" VARCHAR2(4000));
ALTER TABLE "z_devicedesign" ADD ("description" VARCHAR2(4000));