ALTER TABLE "user" ADD ("completeProfile" NUMBER);

ALTER TABLE "z_user" ADD ("completeProfile" NUMBER);