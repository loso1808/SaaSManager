alter table "user" rename column "groupName" to "labName";
alter table "z_user" rename column "groupName" to "labName";

alter table "user" rename column "groupType" to "labType";
alter table "z_user" rename column "groupType" to "labType";