alter table "design_ruleset" drop ("shouldValidate", "shouldFilter");
alter table "z_design_ruleset" drop ("shouldValidate", "shouldFilter");