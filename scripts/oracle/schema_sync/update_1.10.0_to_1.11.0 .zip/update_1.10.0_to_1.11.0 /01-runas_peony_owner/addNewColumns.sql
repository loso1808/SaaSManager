alter table "j5run" add ("next_level_part_id" NUMBER);

alter table "z_j5run" add ("next_level_part_id" NUMBER);

alter table "sequence" add ("library" VARCHAR2(400));

alter table "z_sequence" add ("library" VARCHAR2(400));

alter table "j5run_construct" add ("index" NUMBER);

alter table "z_j5run_construct" add ("index" NUMBER);

