
DEFINE LOG_TABLESPACE_NAME = PNY_RC_1_4_3_LOG;


@@create_z_lock_table.sql;