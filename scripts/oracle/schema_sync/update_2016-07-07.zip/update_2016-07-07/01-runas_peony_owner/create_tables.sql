
DEFINE LOG_TABLESPACE_NAME = PNY_RC_1_4_3_LOG;

@@create_lock_table.sql;

@@create_z_lock_table.sql;

@@create_design_ruleset.sql;

@@create_z_design_ruleset.sql;

@@create_design_rule.sql;

@@create_z_design_rule.sql;

@@create_design_rule_tag.sql;

@@create_z_design_rule_tag.sql;

@@create_attached_design_ruleset.sql;

@@create_z_attached_design_ruleset.sql;

@@create_custom_field.sql;

@@create_z_custom_field.sql;

@@create_custom_field_value.sql;

@@create_z_custom_field_value.sql;

@@create_custom_setting.sql;

@@create_z_custom_setting.sql;