alter table "user" add ("notificationPref" varchar2(400));

alter table "z_user" add ("notificationPref" varchar2(400));