
ALTER TABLE "z_user" DROP ("masterDirectSynthesesList","masterOligoList","masterPlasmidList");

