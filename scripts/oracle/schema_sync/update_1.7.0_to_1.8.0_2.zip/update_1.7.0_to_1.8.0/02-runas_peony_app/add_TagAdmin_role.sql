
Insert into "role" ("id","name","description") values (6,'tag_admin','Can manage and assign permissions for tags.');

COMMIT;