ALTER TABLE "j5run" ADD ("res_dig_group" VARCHAR2(256 BYTE));

commit;
